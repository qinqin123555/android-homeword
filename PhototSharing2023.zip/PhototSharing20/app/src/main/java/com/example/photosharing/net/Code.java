package com.example.photosharing.net;

public class Code {
   public static  final int SUCCESS = 200 ;

}
