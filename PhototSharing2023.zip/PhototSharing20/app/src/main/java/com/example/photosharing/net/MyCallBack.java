package com.example.photosharing.net;

public interface MyCallBack {

}
